<embed src="{{$string}}" width="100%" height="100%" />
<!-- <iframe src="{{$string}}" frameborder="0"></iframe> -->
