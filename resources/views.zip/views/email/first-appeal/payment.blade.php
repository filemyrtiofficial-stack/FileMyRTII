
<p>Dear {{$data['first_name']}} {{$data['last_name']}}</p>
@if($data['appeal_no'] == 1)
<p>
We have successfully received your first appeal application for RTI (Application No: {{$data['application_no'] ?? ''}}) along with the payment of ₹{{$data['charges'] ?? ''}}. The invoice is attached for your refrence.

</p>
@else
<p>
We have successfully received your second appeal application for RTI (Application No: {{$data['application_no'] ?? ''}}) along with the payment of ₹{{$data['charges'] ?? ''}}. The invoice is attached for your refrence.

</p>
@endif
<p>
    <strong>What happens Next?</strong> <br>
    Our experts will process your first appeal within 1-3 business days, and we'll notify you once it is ready for your review and approval. If we require and additional details, our team will get it touch with you.
</p>
<p><strong>Thank you for choosing FileMyRTI.</strong></p>
<p>Warm regards,</p>
<p><strong>FileMyRTI Team</strong></p>
<p>India's Simplest Way to File My RTI</p>
