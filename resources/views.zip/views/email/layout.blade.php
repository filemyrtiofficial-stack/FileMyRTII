
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>First Appeal Assigned – Action Required</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: auto;
            background: #ffffff;
            padding: 20px;
            border-radius: 10px;
            text-align: left;
        }
        p {
            color: #333333;
            font-size: 14px;
            line-height: 1.6;
        }
        .btn-container {
            text-align: center;
            margin-top: 20px;
            margin-bottom: 20px;
        }
        .btn {
            background: #0384D4;
            color: #ffffff;
            text-decoration: none;
            padding: 12px 24px;
            border-radius: 5px;
            display: inline-block;
            font-size: 16px;
            font-weight: bold;
            margin-right: 10px;
        }
        .btn-danger {
            background: #d9534f;
        }
        .btn-secondary {
            background: #FFA500;
        }
        .footer {
            font-size: 12px;
            color: #777777;
            margin-top: 20px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
    @yield('content')
      
    <p><strong>FileMyRTI System</strong></p>
    <p class="footer">FileMyRTI.com | India’s Simplest Way to File My RTI</p>

    </div>
</body>
</html>