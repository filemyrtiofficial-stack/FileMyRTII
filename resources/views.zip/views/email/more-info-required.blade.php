
<p>Hi {{$data['first_name']}} {{$data['last_name']}} </p>

<p>
   This is to cinform that we have received the requested information for your RTI application (Application No: {{$data['application_no'] ?? ''}})
</p>
<p>
   Our team will process It shortly and proceed with the next steps.
</p>

<p>Thank your for choosing FileMyRTI.</p>

<p>Warm regards,</p>
<p><strong>FileMyRTI Team</strong></p>
<p>India's Simplest Way to File My RTI</p>