@foreach($blogs as $key => $value)
    @include('frontend.template.blog_card')

@endforeach