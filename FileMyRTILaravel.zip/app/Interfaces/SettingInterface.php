<?php
namespace App\Interfaces;

interface SettingInterface {
    public function store($data);


}