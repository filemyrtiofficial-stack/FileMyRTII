<?php
namespace App\Interfaces;

interface EnquiryInterface {
    public function delete($id);


}