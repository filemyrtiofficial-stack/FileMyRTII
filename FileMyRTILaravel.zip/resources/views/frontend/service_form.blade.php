@extends('frontend.layout.layout')

@section('content')

<div class="container">

    <div class="row">
        <div class="col-md-8">
    
            <div class="rti_tab_wrapper">
                <div class="rti_tabs">
                    <ul class="rti_tab_list rti_tab_slider">
                        <li><a class="rti_tab_item active fs-28" href="javascript:void(0);" data-toggle="tab" data-id="rti_tab1"><span>Personal Details</span></a></li>
                        <li><a class="rti_tab_item fs-28" href="javascript:void(0);" data-toggle="tab" data-id="rti_tab2"><span>{{$service->name ?? ''}}</span></a></li>
                        <li><a class="rti_tab_item fs-28" href="javascript:void(0);" data-toggle="tab" data-id="rti_tab3"><span>Payment Details</span></a></li>

                    </ul>
                </div>
            </div>
            <div class="rti_tab_details">
                    <div class="rti_tab tab-active" data-id="rti_tab1">
                        <div class="rti_wrapper">
                            <div>
                                <label for="">First Name <span>*</span></label>
                                <input type="text" name="first_name" id="first_name">
                            </div>
                            <div>
                                <label for="">Last Name <span>*</span></label>
                                <input type="text" name="last_name" id="last_name">
                            </div>
                            <div>
                                <label for="">Email Address <span>*</span></label>
                                <input type="text" name="email_address" id="email_address">
                            </div>
                            <div>
                                <label for="">Phone Number <span>*</span></label>
                                <input type="text" name="phone_number" id="phone_number">
                            </div>
                            <div>
                                <label for="">Full Address <span>*</span></label>
                                <input type="text" name="address" id="address">
                            </div>
                            <div>
                                <label for="">Postal Code <span>*</span></label>
                                <input type="text" name="postal_code" id="postal_code">
                            </div>
                        </div>
                        <div>
                            <button data-step="1">Next</button>
                        </div>
                    </div>
                    <div class="rti_tab tab-active" data-id="rti_tab2">
                        <div class="rti_wrapper">
                            @foreach($fields['field_type'] as $key => $field)
                            <div>
                                <label for="">{{$fields['field_lable'][$key] ?? ''}} <span>*</span></label>
                                <input type="text" name="first_name" id="first_name" {{isset($fields['is_required'][$key]) && $fields['is_required'][$key] == 'yes' ? 'required' : ''}}>
                            </div>
                            @endforeach
                            
                        </div>
                        <div>
                            <button data-step="1">Next</button>
                        </div>
                    </div>
                
            </div>
        </div>
    </div>
</div>

@endsection
@push('js')

@endpush