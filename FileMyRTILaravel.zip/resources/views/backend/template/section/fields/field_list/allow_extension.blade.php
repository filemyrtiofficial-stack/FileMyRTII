<div class="form-group"> 
    <label class="form-label">Field Type</label>
    <div class="input-group">
        
    </div>
</div>